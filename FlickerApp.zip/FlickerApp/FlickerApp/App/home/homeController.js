﻿
var app = angular.module("flickerApp");

app.controller('homeController', ['flickerDataService', '$scope', function (flickerDataService, $scope) {
    var controller = this;


    controller.locations = ["Durban", "Delhi", "Johannesburg", "Cape Town", "New York City", "Washington DC", "New Zealand"];
    controller.images = [];
    controller.imageDetails ={} ;



    controller.searchValue = "Delhi";
    controller.mainImageUrl = "";
    controller.currentId = 0;
    controller.perPage = 15;
    controller.currentIndex = 1;
    controller.upperIndex = 5;
    controller.searchFromLocation = function (location) {
        controller.searchValue = location;
        controller.getFlickerData();
    };
    controller.getFlickerData = function () {
        controller.isLoading = true;
        flickerDataService.getSearchData(controller.searchValue, controller.perPage, controller.currentIndex).then(function (data) {
            controller.flickerData = data.photos.photo;
            controller.createImageUrl(controller.flickerData);
            controller.isLoading = false;
        }).catch(function (data) {
            controller.errorMessage = "Oops! Something went wrong.";
            controller.isLoading = false;
        });
    }

    controller.createImageUrl = function (flickerData) {
        controller.urlData = [];
        controller.images = [];
        var url = "";
        if (!angular.isUndefined(flickerData) && flickerData.length > 0) {
            controller.mainImageUrl = "https://farm" + flickerData[0].farm + ".staticflickr.com/" + flickerData[0].server + "/" + flickerData[0].id + "_" + flickerData[0].secret + ".jpg";

            for (var i = 0; i < flickerData.length; i++) {
                url = "https://farm" + flickerData[i].farm + ".staticflickr.com/" + flickerData[i].server + "/" + flickerData[i].id + "_" + flickerData[i].secret + ".jpg";
                controller.urlData.push({ id: i, url: url });
                controller.images.push({ id: flickerData[i].id, url: url });
            }
        }
    }

    controller.init = function () {
        controller.getFlickerData();
        controller.pageIndex();
    }

    controller.searchImages = function () {
        controller.getFlickerData();
    }

    controller.nextImage = function () {
        controller.currentId = controller.currentId + 1;
        if ((!angular.isUndefined(controller.flickerData) && controller.flickerData.length > 0) && (controller.currentId < controller.flickerData.length)) {
            controller.mainImageUrl = "https://farm" + controller.flickerData[controller.currentId].farm + ".staticflickr.com/" + controller.flickerData[controller.currentId].server + "/" + controller.flickerData[controller.currentId].id + "_" + controller.flickerData[controller.currentId].secret + ".jpg";
        }
    }

    controller.previousImage = function () {
        controller.currentId = controller.currentId - 1;
        if (controller.currentId < 0)
            controller.currentId = 0;

        if (!angular.isUndefined(controller.flickerData) && controller.flickerData.length > 0) {
            controller.mainImageUrl = "https://farm" + controller.flickerData[controller.currentId].farm + ".staticflickr.com/" + controller.flickerData[controller.currentId].server + "/" + controller.flickerData[controller.currentId].id + "_" + controller.flickerData[controller.currentId].secret + ".jpg";
        }
    }

    controller.pageIndex = function () {
        controller.indexData = [];
        for (i = controller.currentIndex; i <= controller.upperIndex; i++) {
            controller.indexData.push(i);
        }
    }

    controller.nextIndex = function (index) {
        controller.currentIndex = index + 1;

        var restIndex = controller.upperIndex - index;

        if (index == controller.upperIndex)
            controller.upperIndex = controller.upperIndex + 5;
        else
            controller.upperIndex = controller.upperIndex + 1;

        controller.pageIndex();
        controller.perPage = controller.perPage;
        controller.getFlickerData();
    }

    controller.GetImage = function (index) {
        flickerDataService.getIMageInfo(index).then(function (data) {
            controller.imageDetails = data.photo;
           
            controller.isLoading = false;
        }).catch(function (data) {
            controller.errorMessage = "Oops! Something went wrong.";
            controller.isLoading = false;
        });
    }

    controller.init();
}]);
