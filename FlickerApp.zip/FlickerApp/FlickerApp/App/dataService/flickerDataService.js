﻿var app = angular.module("flickerApp");

app.factory('flickerDataService', ['$http', '$q', function ($http, $q) {

    function getSearchData(searchField, perPage, currentPage) {
        var endPoint = "https://api.flickr.com/services/rest/?method=flickr.photos.search&api_key=4ef2fe2affcdd6e13218f5ddd0e2500d&tags=" + searchField + "%2C+&per_page=" + perPage + "&page=" + currentPage + "&format=json&nojsoncallback=1";
        var req = {
            method: 'GET',
            url: endPoint
        }

        var deferred = $q.defer();
        $http(req).success(function (data) {
            deferred.resolve(data);
        })
          .error(function (err) {
              console.log('Error retrieving data');
              deferred.reject(err);
          });
        return deferred.promise;
    }
    //flickr.photos.getInfo


    function getIMageInfo(imageId) {
        var endPoint = "https://api.flickr.com/services/rest/?method=flickr.photos.getInfo&api_key=4ef2fe2affcdd6e13218f5ddd0e2500d&format=json&nojsoncallback=1&photo_id=49890248291"; // + imageId
        var req = {
            method: 'GET',
            url: endPoint
        }

        var deferred = $q.defer();
        $http(req).success(function (data) {
            deferred.resolve(data);
        })
          .error(function (err) {
              console.log('Error retrieving data');
              deferred.reject(err);
          });
        return deferred.promise;
    }

    return {
        getSearchData: getSearchData,
        getIMageInfo: getIMageInfo
    };
}]);

//services/api/render?method=flickr.photos.getInfo&api_key=1a30b99719af311e60a830757514a9ba&photo_id=49890248291&secret=129fc8b6fd&format=json&nojsoncallback=1